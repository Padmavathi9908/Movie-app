import React from 'react'

const LocalStorage = () => {
    localStorage.setItem('name','padma')
    sessionStorage.setItem('name','padhu')
  return (
    <div>
        <h1>
            Home page
        </h1>
        <h2>localStorage:{localStorage.getItem('name')}</h2>
        <h2>
            sessionStorage:{sessionStorage.getItem('name')}
        </h2>
    </div>
  )
}

export default LocalStorage