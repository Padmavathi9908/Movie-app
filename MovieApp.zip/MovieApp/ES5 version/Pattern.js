import React from 'react'

const Pattern = () => {
    let n = 5;
    // Upside pyramid
    for (let i = 1; i <= n; i++) {
      // printing spaces
      for (let j = 1; j <= n - i; j++) {
        document.write("  ");
      }
      // printing star
      for (let k = 0; k < 2 * i - 1; k++) {
       document.write('*')
      }
      console.log(document.write());
    }

    // downside pyramid
    for (let i = 1; i <= n - 1; i++) {
      // printing spaces
      for (let j = 0; j < i; j++) {
         document.write(' ');
      }
      // printing star
      for (let k = (n - i) * 2 - 1; k > 0; k--) {
        document.write('*');
      }
    }
}

export default Pattern